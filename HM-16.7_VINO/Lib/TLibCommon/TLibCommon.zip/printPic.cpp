#include "printPic.h"

void print_pic(const char* file_name,TComPicYuv* rec_pic)
{   
	Pel* rec_pic_y = rec_pic->getAddr(COMPONENT_Y,0);
	Pel* rec_pic_u = rec_pic->getAddr(COMPONENT_Cb,0);
	Pel* rec_pic_v = rec_pic->getAddr(COMPONENT_Cr,0);
	int height, width;
    height = rec_pic->getHeight(COMPONENT_Y);
	width=rec_pic->getWidth(COMPONENT_Y);

	FILE* fid = fopen("height_width", "wb+");
	short hw[2];
	hw[0] = (short) height;
	hw[1] = (short) width;
	fwrite(hw, sizeof(short), sizeof(hw), fid);
	fclose(fid);

	const int Y_size = height*width;
	UChar* ucy=new UChar[Y_size];
	UChar* ucu=new UChar[Y_size/4];
	UChar* ucv=new UChar[Y_size/4];
	int strideY = rec_pic->getStride(COMPONENT_Y);
	int strideU = rec_pic->getStride(COMPONENT_Cb);
	int strideV = rec_pic->getStride(COMPONENT_Cr);
	for (int i=0;i<height;i++)
	{
		for (int j = 0; j < width; j++)
		{
			ucy[i*width + j] = (UChar) rec_pic_y[i*strideY + j];
		}
	}
	for (int i = 0; i<height/2; i++)
	{
		for (int j = 0; j<width/2; j++)
		{
			ucu[i*width/2 + j] = (UChar) rec_pic_u[i*strideU + j];
			ucv[i*width/2 + j] = (UChar) rec_pic_v[i*strideU + j];
		}
	}

	FILE* ruf = fopen(file_name, "ab");
	fwrite(ucy, sizeof(UChar), Y_size, ruf);
	fwrite(ucu, sizeof(UChar), Y_size/4, ruf);
	fwrite(ucv, sizeof(UChar), Y_size/4, ruf);
	fclose(ruf);
	delete[] ucy;
	delete[] ucu;
	delete[] ucv;
}
